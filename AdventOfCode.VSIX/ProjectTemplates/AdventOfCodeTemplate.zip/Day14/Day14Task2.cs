﻿namespace $safeprojectname$.Day14
{
    using AdventOfCode.Common;

    public class Day14Task2 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}