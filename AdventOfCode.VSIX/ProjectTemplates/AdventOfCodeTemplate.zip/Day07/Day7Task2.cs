﻿namespace $safeprojectname$.Day07
{
    using AdventOfCode.Common;

    public class Day7Task2 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}