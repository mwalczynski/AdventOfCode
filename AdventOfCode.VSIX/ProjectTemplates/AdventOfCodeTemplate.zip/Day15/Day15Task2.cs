﻿namespace $safeprojectname$.Day15
{
    using AdventOfCode.Common;

    public class Day15Task2 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}