﻿namespace $safeprojectname$.Day20
{
    using AdventOfCode.Common;

    public class Day20Task1 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}