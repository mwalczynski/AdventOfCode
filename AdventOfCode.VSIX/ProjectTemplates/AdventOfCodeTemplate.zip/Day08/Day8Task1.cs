﻿namespace $safeprojectname$.Day08
{
    using AdventOfCode.Common;

    public class Day8Task1 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}