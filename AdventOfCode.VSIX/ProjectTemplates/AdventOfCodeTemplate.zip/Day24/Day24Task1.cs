﻿namespace $safeprojectname$.Day24
{
    using AdventOfCode.Common;

    public class Day24Task1 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}