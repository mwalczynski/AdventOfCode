﻿namespace $safeprojectname$.Day22
{
    using AdventOfCode.Common;

    public class Day22Task2 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}