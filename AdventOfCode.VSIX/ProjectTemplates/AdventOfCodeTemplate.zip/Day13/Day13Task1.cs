﻿namespace $safeprojectname$.Day13
{
    using AdventOfCode.Common;

    public class Day13Task1 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}