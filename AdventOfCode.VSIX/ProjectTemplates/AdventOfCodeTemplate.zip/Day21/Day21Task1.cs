﻿namespace $safeprojectname$.Day21
{
    using AdventOfCode.Common;

    public class Day21Task1 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}