﻿namespace $safeprojectname$.Day21
{
    using AdventOfCode.Common;

    public class Day21Task2 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}