﻿namespace $safeprojectname$.Day05
{
    using AdventOfCode.Common;

    public class Day5Task2 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}