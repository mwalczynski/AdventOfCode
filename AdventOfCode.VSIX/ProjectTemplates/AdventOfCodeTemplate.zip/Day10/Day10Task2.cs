﻿namespace $safeprojectname$.Day10
{
    using AdventOfCode.Common;

    public class Day10Task2 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}