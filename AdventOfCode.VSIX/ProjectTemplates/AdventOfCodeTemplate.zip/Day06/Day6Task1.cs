﻿namespace $safeprojectname$.Day06
{
    using AdventOfCode.Common;

    public class Day6Task1 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}