﻿namespace $safeprojectname$.Day25
{
    using AdventOfCode.Common;

    public class Day25Task2 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}