﻿namespace $safeprojectname$.Day19
{
    using AdventOfCode.Common;

    public class Day19Task2 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}