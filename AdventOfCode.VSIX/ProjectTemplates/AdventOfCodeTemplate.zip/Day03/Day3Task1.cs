﻿namespace $safeprojectname$.Day03
{
    using AdventOfCode.Common;

    public class Day3Task1 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}