﻿namespace $safeprojectname$.Day04
{
    using AdventOfCode.Common;

    public class Day4Task2 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}