﻿namespace $safeprojectname$
{
    using AdventOfCode.Common;

    public class AutofacModule : DayAutofacModule
    {
    }
}
