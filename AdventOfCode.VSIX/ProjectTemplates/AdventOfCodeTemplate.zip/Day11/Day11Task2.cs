﻿namespace $safeprojectname$.Day11
{
    using AdventOfCode.Common;

    public class Day11Task2 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}