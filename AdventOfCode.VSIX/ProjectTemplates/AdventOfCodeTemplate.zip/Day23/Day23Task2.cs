﻿namespace $safeprojectname$.Day23
{
    using AdventOfCode.Common;

    public class Day23Task2 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}