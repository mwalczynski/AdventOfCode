﻿namespace $safeprojectname$.Day23
{
    using AdventOfCode.Common;

    public class Day23Task1 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}