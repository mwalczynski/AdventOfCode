﻿namespace $safeprojectname$.Day17
{
    using AdventOfCode.Common;

    public class Day17Task1 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}