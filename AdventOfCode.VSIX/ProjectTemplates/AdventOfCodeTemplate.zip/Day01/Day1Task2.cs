﻿namespace $safeprojectname$.Day01
{
    using AdventOfCode.Common;

    public class Day1Task2 : BaseDay
    {
        public override string GetResult(string[] input)
        {
            throw new System.NotImplementedException();
        }
    }
}